# Dummy_Device
# Before using this example, please install the python module 'requests' correctly.

Modify your userdefined code in "SA.py", and execute "DAI.py" to run the DA, for example" "python3 DAI.py"


